import React, { Component } from 'react';
import './App.css';

const originalData =  [
  { name: 'Alpha', ratings: '6', duration: '2h' },
  { name: 'Beauty and The Beast', ratings: '7.5', duration: '2.5h' },
  { name: 'The Godfather', ratings: '7.5', duration: '300m' },
  { name: 'The Suits', ratings: '8', duration: '12h' },
  { name: 'Friends', ratings: '9.2', duration: '2000m' },
  { name: 'HIMYM', ratings: '9', duration: '7w' },
  { name: 'Friends', ratings: '9.2', duration: '2000m' },
  { name: 'The Suits', ratings: '8', duration: '12h' },
  { name: 'The Godfather', ratings: '7.5', duration: '300m' },
  { name: 'Beauty and The Beast', ratings: '7.5', duration: '2.5h' },
  { name: 'Alpha', ratings: '6', duration: '2h' },
]

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { 
      name: '',
      ratings:'',
      duration:'',
      data:originalData,
      searchInput: '',
     };
  }

  mySubmitHandler = (e) => {
      e.preventDefault();
      let data = [...this.state.data];
      data.push({
        name: this.state.name, 
        ratings: this.state.ratings,
        duration: this.state.duration
      });
      this.setState({
        data,
      });
  }

  handleChange = event => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  };

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = originalData.filter(value => {
      return (
        value.name.toLowerCase().includes(searchInput.toLowerCase())||
        value.ratings.toLowerCase().includes(searchInput.toLowerCase())||
        value.duration.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ data: filteredData });
  };

  renderTableHeader() {
    let header = Object.keys(this.state.data[0])
    return header.map((key, index) => {
       return <th key={index}>{key.toUpperCase()}</th>
    })
 }

 renderTableData() {
    return this.state.data.map((data, index) => {
       const { name, ratings, duration } = data //destructuring
       return (
          <tr key={index}>
             <td>{name}</td>
             <td>{ratings}</td>
             <td>{duration}</td>
          </tr>
       )
    })
 }

  render () {
    return (
      <div>
      <>
      <h1>Favorite movie directory</h1>
           <div class="row">
             <div class="column">
               <label>Search</label>
                   <input
                       type="text"
                       id="search-input"
                       value={this.state.searchInput || ""}
                       onChange={this.handleChange}
                     />
                   <table id="directory-table">
                   {this.state.data.length > 0 ? 
                          <tbody>
                               <tr>{this.renderTableHeader()}</tr>
                                  {this.renderTableData()}
                           </tbody>
                          :<label id="no-result">no results</label>
                   }
                        
                   </table>
             </div>
               <div class="column">
               <form  onSubmit={this.mySubmitHandler}>
                       <label>Movie Name</label>
                       <input type="text" id="name-input" onChange={event =>  this.setState({name: event.target.value})}/>
                       <label>Ratings</label>
                       <input type="text" id="ratings-input" onChange={event =>  this.setState({ratings: event.target.value})} />
                       <label>Duration</label>
                       <input type="text" id="duration-input" onChange={event =>  this.setState({duration: event.target.value})} />
                       <button  id="submit-button" type='submit'>Submit</button>
                   </form>
               </div>
           </div>
     </>
     </div>
    );
  }
}

export default App;
